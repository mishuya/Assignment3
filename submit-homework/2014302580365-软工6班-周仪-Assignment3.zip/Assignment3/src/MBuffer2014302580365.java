import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.nodes.Document;


public class MBuffer2014302580365{
	private static ArrayList<Document> trueDoc=new ArrayList<Document>();

	public synchronized void addToBuffer(Document doc1) throws IOException{
		trueDoc.add(doc1);
	}

	public synchronized ArrayList<Document> getFromBuffer(){
		return trueDoc;
	}
}
