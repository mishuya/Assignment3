import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;


public class MDataBase2014302580365 implements Runnable{
	private MParser2014302580365 parser;

	public MDataBase2014302580365(MParser2014302580365 parser){
		this.parser=parser;
	}
	//连接数据库
	public java.sql.Connection connectDatabase() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		java.sql.Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"
				+ "CrawlTeachers?useUnicode=true&characterEncoding=utf-8", 
				"root", "zhouzhou1024");
		return con;
	}
	//将数据插入到数据库
	public void updateDatabase(java.sql.Connection con) throws SQLException{
		parser.getAllInfor();
		int m = 1;
		for(int i = 0;i < 7;i++){
			PreparedStatement insertInfor = con.prepareStatement("insert into Teachers values(?,?,?,?,?)");
			insertInfor.setInt(1,m++);
			insertInfor.setString(2, parser.getName()[i]);
			insertInfor.setString(3, parser.getPhoneNumber()[i]);
			insertInfor.setString(4, parser.getEmail()[i]);
			insertInfor.setString(5, parser.getIntroduction()[i]);
			insertInfor.executeUpdate();
		}		
	}

	@Override
	public void run(){
		// TODO Auto-generated method stub
		try{
			while(parser.getDoc().size()!=7){
				try {
					TimeUnit.MILLISECONDS.sleep(200);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			java.sql.Connection con0 = connectDatabase();
			updateDatabase(con0);
			con0.close();
		}catch(Exception e){
			e.printStackTrace();
		}

	}
}
