import java.io.IOException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class CrawlTeachers2014302580365 {
	public static void main(String[] args) throws Exception{
		//单线程开始
		System.out.println("SingleThread starts.");
		long startTimeStamp = System.currentTimeMillis();
		int i = 0;
		int m = 1;
		String fatherUrl = "http://www.xwxy.fudan.edu.cn/node2/fdxwxy/jzyg/node816/node905/index.html";
		String [] urls = new String[24];
		String PhoneNumber;
		String Email;
		String Introduction;
		try {
			//连接JDBC数据库
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection  con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/CrawlTeachers?useUnicode=true&characterEncoding=utf-8", 
					"root", "zhouzhou1024");
			//Jsoup解析首页
			Document doc = Jsoup.connect(fatherUrl).timeout(60000000).get();
			//取得页面中教师个人主页URL地址
			Elements links = doc.getElementsByClass("hui12a");
			for(Element link:links){
				urls[i] = link.attr("abs:href");
				i++;
			} 
			for(int k = 0;k < urls.length;k++){
				if(k == 2||k == 4|| k == 7 || k == 12 || k ==16 || k == 17 || k == 18){
					Document doc1 = Jsoup.connect(urls[k]).timeout(60000000).get();
					String name = doc1.getElementsByClass("b18").text();
					Elements content = doc1.getElementsByTag("p");
					String introduction = content.text();
					//用正则表达式分别获取姓名，研究领域等具体信息
					String regex1 = "(\\d{3}-\\d{8})";
					String regex2 = "[a-z]+@([a-z]+)\\.([a-z]+)\\.([a-z]+)|[a-z]+@([a-z]+)\\.([a-z]+)";
					String regex3 = "研究领域：([\u4e00-\u9fa5]+)|研究领域 ([\u4e00-\u9fa5]+)\\、([\u4e00-\u9fa5]+)";
					String regex4 = "职称职务 ([\u4e00-\u9fa5]+)|职称职务：([\u4e00-\u9fa5]+) ";
					Matcher matcher1 = Pattern.compile(regex1).matcher(introduction);
					if(matcher1.find()){
						PhoneNumber = matcher1.group(0);
					}else{
						PhoneNumber = " ";
					}
					Matcher matcher2 = Pattern.compile(regex2).matcher(introduction);
					if(matcher2.find()){
						Email = matcher2.group(0);
					}else{
						Email = " ";
					}
					Matcher matcher3 = Pattern.compile(regex3).matcher(introduction);
					if(matcher3.find()){
						Introduction = matcher3.group(0);
					}else{
						Introduction = " ";
					}
					Matcher matcher4 = Pattern.compile(regex4).matcher(introduction);
					if(matcher4.find()){
						Introduction = Introduction + "\t" +matcher4.group(0);
					}else{
						Introduction +=" ";
					}
					//将数据插入到数据库中
					PreparedStatement insertInfor = con.prepareStatement("insert into Teachers values(?,?,?,?,?)");
					insertInfor.setInt(1,m++);
					insertInfor.setString(2, name);
					insertInfor.setString(3, PhoneNumber);
					insertInfor.setString(4, Email);
					insertInfor.setString(5, Introduction);
					insertInfor.executeUpdate();
				}
			}			
			//关闭数据库连接
			con.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Processing Time: " + Long.toString(System.currentTimeMillis() - startTimeStamp) + " ms.");

		//多线程开始
		System.out.println("MultiThread starts.");
		long startTimeStamp1 = System.currentTimeMillis();
		MBuffer2014302580365 buffer=new MBuffer2014302580365();
		Thread tCrawl = new Thread(new MCrawler2014302580365(buffer),"crawl");
		MParser2014302580365 parser=new MParser2014302580365(buffer);
		Thread tParser = new Thread(parser,"parser");
		Thread tDatabase = new Thread(new MDataBase2014302580365(parser),"database");
		tCrawl.start();
		tParser.start();
		tDatabase.start();
		tCrawl.join();
		tParser.join();
		tDatabase.join();
		System.out.println("Processing Time: " + Long.toString(System.currentTimeMillis() - startTimeStamp1) + " ms.");

	}
}
