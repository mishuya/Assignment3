import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class MCrawler2014302580365 implements Runnable{
	private int i = 0;
	private String[] urls = new String[24];
	private String[] trueUrls = new String[7];
	private Document[] doc=new Document[7];
	private MBuffer2014302580365 mbuffer0;

	public MCrawler2014302580365(MBuffer2014302580365 m){
		this.mbuffer0 = m;
	}

	public String[] getTrueUrls() {
		return trueUrls;
	}

	public void setTrueUrls(String[] trueUrls) {
		this.trueUrls = trueUrls;
	}

	public Document[] getDoc() {
		return doc;
	}

	public void setDoc(Document[] doc) {
		this.doc = doc;
	}
	//获得所有的教师个人主页链接URL
	public String[] getUsefulUrls(String url) throws IOException{
		Document doc0 = Jsoup.connect(url).timeout(6000000).get();
		Elements links = doc0.getElementsByClass("hui12a");
		for(Element link:links){
			urls[i] = link.attr("abs:href");
			i++;
		}
		int m = 0;
		for(int k = 0;k < 24;k++){
			if(k == 2||k == 4|| k == 7 || k == 12 
					|| k ==16 || k == 17 || k == 18){
				trueUrls[m] = urls[k];
				m++;
			}
		}	
		return trueUrls;
	}	
	//爬取有效的教师个人主页，并将相应的document存放到buffer中
	public Document[] crawlDoc(String[] url) throws IOException{
		for(int i = 0;i < url.length;i++){
			doc[i] = Jsoup.connect(url[i]).timeout(6000000).get();
			mbuffer0.addToBuffer(doc[i]);
		}
		return doc;
	}
	//真正应用到本次爬取实验中
	public Document[] getFinalDoc() throws IOException{
		String fatherUrl = "http://www.xwxy.fudan.edu.cn/node2/"
				+ "fdxwxy/jzyg/node816/node905/index.html";
		return crawlDoc(getUsefulUrls(fatherUrl));
	}
	
	@Override
	public void run(){
		// TODO Auto-generated method stub
		try {
			getFinalDoc();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
