import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.nodes.Document;


public class MParser2014302580365 implements Runnable{
	private MBuffer2014302580365 mBuffer0;
	private String content[] = new String[7];
	private String name[] = new String[7];
	private String phoneNumber[] = new String[7];
	private String email[] = new String[7];
	private String introduction[] = new String[7];

	public MParser2014302580365(MBuffer2014302580365 m){
		this.mBuffer0=m;
	}

	public String[] getContent() {
		return content;
	}

	public void setContent(String[] content) {
		this.content = content;
	}

	public String[] getName() {
		return name;
	}

	public void setName(String[] name) {
		this.name = name;
	}

	public String[] getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String[] phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String[] getEmail() {
		return email;
	}

	public void setEmail(String[] email) {
		this.email = email;
	}

	public String[] getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String[] introduction) {
		this.introduction = introduction;
	}
	//从buffer中获取document
	public ArrayList<Document> getDoc(){
		return mBuffer0.getFromBuffer();
	}
	//获取所有有效信息
	public String getFinalContent(Document doc){
		String content0 = doc.getElementsByTag("p").text();
		return content0;
	}
	//从有效信息中获取教师名字
	public String getFinalName(Document doc){
		String name0 = doc.getElementsByClass("b18").text();
		return name0;
	}
	//从有效信息中获取教师电话号码
	public String getFinalPhoneNumber(String c){
		String phoneNumber0;
		String regex1 = "(\\d{3}-\\d{8})";
		Matcher matcher1 = Pattern.compile(regex1).matcher(c);
		if(matcher1.find()){
			phoneNumber0 = matcher1.group(0);
		}else{
			phoneNumber0 = " ";
		}
		return phoneNumber0;
	}
	//从有效信息中获取教师邮箱
	public String getFinalEmail(String c){
		String email0;
		String regex2 = "[a-z]+@([a-z]+)\\.([a-z]+)\\.([a-z]+)|[a-z]+@([a-z]+)\\.([a-z]+)";
		Matcher matcher2 = Pattern.compile(regex2).matcher(c);
		if(matcher2.find()){
			email0 = matcher2.group(0);
		}else{
			email0 = " ";
		}
		return email0;
	}
	//从有效信息中获取教师研究领域等简介
	public String getFinalIntroduction(String c){
		String introduction0;
		String regex3 = "研究领域：([\u4e00-\u9fa5]+)|研究领域 ([\u4e00-\u9fa5]+)\\、([\u4e00-\u9fa5]+)";
		String regex4 = "职称职务 ([\u4e00-\u9fa5]+)|职称职务：([\u4e00-\u9fa5]+) ";
		Matcher matcher3 = Pattern.compile(regex3).matcher(c);
		if(matcher3.find()){
			introduction0 = matcher3.group(0);
		}else{
			introduction0 = " ";
		}
		Matcher matcher4 = Pattern.compile(regex4).matcher(c);
		if(matcher4.find()){
			introduction0 = introduction0 + "\t" +matcher4.group(0);
		}else{
			introduction0 +=" ";
		}
		return introduction0;
	}	
	//具体应用到本次爬取实验中
	public void getAllInfor(){
		for(int i = 0;i < 7;i++){
			Document doc= getDoc().get(i);
			content[i] = getFinalContent(doc);
			name[i] = getFinalName(doc);
			phoneNumber[i] = getFinalPhoneNumber(content[i]);
			email[i] = getFinalEmail(content[i]);
			introduction[i] = getFinalIntroduction(content[i]);
		}		
	}
	
	@Override
	public void run() {
		while(getDoc().size()!=7){
			try {
				TimeUnit.MILLISECONDS.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		getAllInfor();
	}
}
